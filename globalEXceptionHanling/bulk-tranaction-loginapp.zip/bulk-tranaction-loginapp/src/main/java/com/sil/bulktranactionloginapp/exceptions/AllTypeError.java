package com.sil.bulktranactionloginapp.exceptions;

public class AllTypeError extends RuntimeException{
    public AllTypeError(String message) {
        super(message);
    }
}
