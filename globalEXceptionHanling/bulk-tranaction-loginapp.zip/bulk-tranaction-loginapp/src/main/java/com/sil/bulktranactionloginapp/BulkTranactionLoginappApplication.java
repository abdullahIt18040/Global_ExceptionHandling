package com.sil.bulktranactionloginapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BulkTranactionLoginappApplication {

    public static void main(String[] args) {
        SpringApplication.run(BulkTranactionLoginappApplication.class, args);
    }

}
