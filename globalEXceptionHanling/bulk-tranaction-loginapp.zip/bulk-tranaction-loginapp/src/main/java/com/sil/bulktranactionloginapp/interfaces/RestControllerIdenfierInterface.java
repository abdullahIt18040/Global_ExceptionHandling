package com.sil.bulktranactionloginapp.interfaces;

public interface RestControllerIdenfierInterface {
}
