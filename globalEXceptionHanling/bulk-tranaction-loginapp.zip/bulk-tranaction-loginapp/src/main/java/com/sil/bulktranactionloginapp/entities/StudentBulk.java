package com.sil.bulktranactionloginapp.entities;

public record StudentBulk(int id, String name, double cgpa){

}